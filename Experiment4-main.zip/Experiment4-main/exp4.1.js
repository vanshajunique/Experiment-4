const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
console.log("Management System");
console.log("1. Add Employee");
console.log("2. List Employee");
console.log("3. Update");
console.log("4. Delete");
console.log("5. Exit");
let employees =[];
function menu(){
    console.log("\n1.Add 2.List 3.Update 4.Delete 5.Exit");

    rl.question("Choose:",function(choice){
   if(choice==1 ) addemployee();
   else if(choice==2) listemployee();
   else if (choice == 3) updateEmployee();
   else if (choice == 4) deleteEmployee();
   else rl.close();
    }
);
    }
    function addEmployee() {
    rl.question("Enter ID: ", function (id) {
        rl.question("Enter Name: ", function (name) {
            employees.push({ id, name });
            console.log("Employee Added!");
            menu();
        });
    });
}

function listEmployee() {
    console.log(employees);
    menu();
}
function updateEmployee() {
    rl.question("Enter ID to update: ", function (id) {
        let emp = employees.find(e => e.id == id);

        if (emp) {
            rl.question("Enter new Name: ", function (name) {
                emp.name = name;
                console.log("Updated!");
                menu();
            });
        } else {
            console.log("Employee not found");
            menu();
        }
    });
}

// Delete Employee
function deleteEmployee() {
    rl.question("Enter ID to delete: ", function (id) {
        employees = employees.filter(e => e.id != id);
        console.log("Deleted!");
        menu();
    });
}

menu();

